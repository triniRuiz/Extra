from django.db import models

# Create your models here.

class trabajador(models.Model):
    nombre= models.TextField()
    clave=models.CharField(max_length=5)
    foto=models.ImageField(null=True,upload_to="foto",verbose_name="Foto")
    created = models.DateTimeField(auto_now_add=True)  
    updated = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name='trabajador'
        verbose_name_plural='trabajadores'
        ordering=["-created"]
        def __str__(self):
            return self.nombre

class Material(models.Model):
    
    nombre=models.TextField(verbose_name="nombre")
    material=models.CharField(max_length=28)
    carrera=models.TextField()
    created = models.DateTimeField(auto_now_add=True)  
    updated = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name="material"
        verbose_name_plural="materiales"
        ordering=["-created"]
        def __str__(self):
            return self.nombre

