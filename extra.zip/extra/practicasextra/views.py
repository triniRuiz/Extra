from django.shortcuts import render
from .models import Material

# Create your views here.

def inicio(request):
    return render(request, "practicasextra/inicio.html")

def solicitud(request):
    
    return render(request, "practicasextra/formulario.html")

def material(request):
    material=Material.objects.all()
    return render(request, "practicasextra/material.html",)


    