from django.contrib import admin
from .models import Material,trabajador

class AdministrarModelo(admin.ModelAdmin):
    readonly_fields=('created', 'updated')
admin.site.register(Material, AdministrarModelo)
admin.site.register(trabajador)
